# PI Planner — Jira Live (prototype exécutable)

Agent Gemini CLI + MCP Jira EDF + board HTML/JS local.

## Prérequis
- Windows, Python 3.10+ (sans dépendance pip)
- Gemini CLI installé, authentifié et accessible via `gemini`
- Serveur MCP Jira EDF configuré dans Gemini CLI avec accès lecture aux issues et aux liens
- Accès VPN EDF si requis

## Démarrer (PowerShell)
```powershell
cd pi-planner-jira-live
python server.py
```
Ouvrir `http://127.0.0.1:8765` dans le navigateur.

Si la commande `gemini` n'est pas reconnue, vérifier `gemini --version`, `where.exe gemini` et le PATH npm global. Sur Windows, `gemini.cmd` peut être nécessaire dans `config/settings.json`.

## Premier import
1. Vérifier le projet `DORZDATAPULCO`.
2. Le champ de PI est provisoirement `Version Cible`. Le modifier dans **Paramètres Jira > Champ PI**, ou dans `config/settings.json` (`piFieldName`).
3. Renseigner **Valeur du PI** (obligatoire).
4. Cliquer **Enregistrer**, puis **Importer depuis Jira MCP**.
5. Contrôler les alertes et les liens récupérés.
6. Déplacer les tickets par glisser-déposer. Ces déplacements sont **locaux uniquement**.

## Architecture
- `agent/SKILL.md` : règles de l'agent et de la planification
- `agent/import_prompt.txt` : prompt Gemini CLI demandant l'utilisation du MCP Jira
- `agent/schema.json` : contrat de sortie
- `server.py` : serveur local et adaptateur Gemini CLI
- `web/index.html` : board interactif, configuration et visualisation des liens
- `config/settings.json` : configuration modifiable
- `data/board.json` : données importées et placements locaux (créé au premier import)

## Sécurité
- Ne pas mettre de token Jira dans le navigateur, les fichiers du projet ou les prompts.
- Gemini CLI doit utiliser la connexion MCP Jira existante de l'utilisateur.
- Serveur limité à `127.0.0.1`; ne pas l'exposer sur le réseau.
- Aucune opération d'écriture Jira n'est implémentée. La publication nécessitera un diff, une validation explicite et un contrôle des droits.
- Le fichier `data/board.json` peut contenir des informations Jira internes : ne pas le partager hors des espaces autorisés.

## Limites de cette première version
- L'import via Gemini CLI/MCP est implémenté mais **non testé sur l'instance EDF**; il dépend des outils effectivement exposés par le serveur MCP et du format de sortie Gemini CLI.
- Pour de gros PI, le volume JSON peut dépasser la fenêtre de contexte de Gemini; la pagination est demandée, mais le streaming paginé côté backend sera une amélioration nécessaire.
- Les liens Jira sont récupérés sous forme de données et présentés en liste. Le graphe interactif à flèches, le calcul complet des capacités, l'optimiseur et la publication vers Jira ne sont pas encore implémentés.
- Le classement DEV/RECETTE/DOC est heuristique dans cette version et devra être configurable par labels ou types Jira.
- Les tickets externes sont importés en métadonnées mais non placés dans les sprints.

## Fichier capacité obligatoire — format NET
Déposer / modifier `input/Template_Capacite_PI_Planner.xlsx`. Les onglets sont `Capacite` (NOM, ROLE, SPRINT 1...), `Sprints` (SPRINT, DATE DEBUT, DATE FIN), `Absences` (NOM, DATE DEBUT, DATE FIN, INDISPONIBILITE (%), MOTIF).
**Les points sont déjà nets : aucune déduction d’absence.** Les dates servent à identifier les fenêtres de travail pour les US. Le board autonome `output/board_pip.html` affiche la capacité inchangée et un calendrier des disponibilités.

Démarrage : `python server.py`, puis `http://127.0.0.1:8765`. Configurer le PI, importer depuis MCP Jira, générer le HTML. MCP Jira doit être configuré sur le poste.

Limites : le moteur ne déduit pas une durée calendaire de story points, ne réalise pas encore une optimisation automatique à la journée, et l’import MCP EDF n’est pas testé ici.

## Centre d'arbitrage
Dans `output/board_pip.html`, cliquer sur **Analyser les conflits**. Les scénarios proposent des déplacements, réaffectations ou un split à étudier. **Prévisualiser et appliquer** demande confirmation et change uniquement le board local. **Annuler/Rétablir** permet de revenir en arrière. Sauvegarder ensuite le HTML ou exporter le JSON. Aucune écriture Jira n'est réalisée.

Limites : le contrôle de recette indépendante repose sur les liens DEV→RECETTE disponibles ; les compétences sont approximées par le rôle ; sans dates de jalon, le séquencement dans le même sprint reste à vérifier. Ce moteur local déterministe n'est pas un solveur d'optimisation globale ni une invocation Gemini en direct.

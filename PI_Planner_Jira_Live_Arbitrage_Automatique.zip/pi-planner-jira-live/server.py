"""PI Planner Jira Live: local-only UI and Gemini CLI/MCP read bridge."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json, subprocess, re, os, threading
from capacity import parse_capacity

ROOT = Path(__file__).resolve().parent
SETTINGS = ROOT / 'config' / 'settings.json'
DATA = ROOT / 'data' / 'board.json'
CAPACITY = ROOT / 'input' / 'Template_Capacite_PI_Planner.xlsx'
OUTPUT = ROOT / 'output' / 'board_pip.html'
LOCK = threading.Lock()
MAX_BODY = 3_000_000

def load_json(path, default):
    try: return json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError: return default

def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
    tmp.replace(path)

def parse_response(stdout):
    # gemini -o json may wrap the answer in {"response":"..."}.
    raw = json.loads(stdout)
    if isinstance(raw, dict) and 'response' in raw and isinstance(raw['response'], str):
        raw = raw['response']
    if isinstance(raw, str):
        raw = raw.strip()
        raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw)
        raw = json.loads(raw)
    if not isinstance(raw, dict): raise ValueError('Réponse Gemini non conforme: objet JSON attendu')
    return raw

def normalize(data, cfg):
    if not isinstance(data.get('issues'), list) or not isinstance(data.get('links'), list):
        raise ValueError('Réponse MCP incomplète: issues/links absents')
    issues, keys = [], set()
    for item in data['issues']:
        if not isinstance(item, dict) or not isinstance(item.get('key'), str) or not isinstance(item.get('summary'), str):
            continue
        if item['key'] in keys: continue
        keys.add(item['key'])
        issues.append({**item, 'sprint': item.get('sprint') or 'Non planifiés', 'external': bool(item.get('external', False)),
                       'points': item.get('points') if isinstance(item.get('points'), (int, float)) else None})
    links, seen = [], set()
    for link in data['links']:
        if not isinstance(link, dict): continue
        src, dst, typ = link.get('source'), link.get('target'), link.get('type')
        if not all(isinstance(v, str) and v for v in (src, dst, typ)): continue
        signature = (src, dst, typ)
        if signature in seen: continue
        seen.add(signature)
        links.append({**link, 'blocking': bool(link.get('blocking', False))})
    return {'project': cfg['projectKey'], 'piValue': cfg['piValue'], 'issues': issues, 'links': links,
            'warnings': data.get('warnings', []) if isinstance(data.get('warnings'), list) else [],
            'partial': bool(data.get('partial', False))}

def import_jira(cfg):
    if not cfg.get('piValue', '').strip(): raise ValueError('Renseigne la valeur du PI avant import.')
    schema = (ROOT/'agent'/'schema.json').read_text(encoding='utf-8')
    template = (ROOT/'agent'/'import_prompt.txt').read_text(encoding='utf-8')
    prompt = template.format(project=cfg['projectKey'], field=cfg['piFieldName'], pi=cfg['piValue'],
                             limit=cfg.get('issueLimit', 500), external=cfg.get('includeExternalDependencies', True), schema=schema)
    cmd = cfg.get('geminiCommand', 'gemini')
    if cmd not in ('gemini', 'gemini.cmd', 'gemini.exe'):
        raise ValueError('Commande Gemini non autorisée. Utilise gemini ou gemini.cmd.')
    try:
        result = subprocess.run([cmd, '-p', prompt, '-o', 'json'], cwd=ROOT, capture_output=True,
                                text=True, timeout=240, shell=False, encoding='utf-8', errors='replace')
    except FileNotFoundError as exc:
        raise ValueError('Gemini CLI introuvable. Vérifie le PATH ou lance le serveur depuis le terminal Gemini.') from exc
    except subprocess.TimeoutExpired as exc:
        raise ValueError('Délai Gemini CLI dépassé (240 s). Réduis le périmètre ou augmente la limite côté code.') from exc
    if result.returncode:
        raise ValueError('Gemini CLI a échoué : ' + result.stderr[-1500:])
    return normalize(parse_response(result.stdout), cfg)

class Handler(BaseHTTPRequestHandler):
    def respond(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store'); self.send_header('Content-Length', str(len(data)))
        self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/config': return self.respond(200, load_json(SETTINGS, {}))
        if path == '/api/board': return self.respond(200, load_json(DATA, {'issues':[], 'links':[], 'warnings':[]}))
        if path == '/api/capacity':
            try:return self.respond(200,parse_capacity(CAPACITY))
            except Exception as exc:return self.respond(400,{'error':str(exc)})
        if path == '/api/output':
            if not OUTPUT.exists():return self.respond(404,{'error':'Génère le HTML depuis le board'})
            data=OUTPUT.read_bytes()
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Disposition','attachment; filename="board_pip.html"')
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if path in ('/', '/index.html'):
            data = (ROOT/'web'/'index.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)
            return
        self.respond(404, {'error':'Route inconnue'})
    def do_POST(self):
        path = urlparse(self.path).path
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if size <= 0 or size > MAX_BODY: raise ValueError('Taille de requête invalide')
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict): raise ValueError('Objet JSON attendu')
            with LOCK:
                if path == '/api/config':
                    old = load_json(SETTINGS, {})
                    allowed = {'projectKey','piFieldName','piValue','sprintCount','sprintWeeks','includeExternalDependencies','readOnly','issueLimit'}
                    cfg = {**old, **{k:v for k,v in payload.items() if k in allowed}}
                    if not isinstance(cfg.get('projectKey'), str) or not re.fullmatch(r'[A-Za-z0-9_-]{2,80}', cfg['projectKey']): raise ValueError('Clé de projet invalide')
                    if not isinstance(cfg.get('piFieldName'), str) or not cfg['piFieldName'].strip(): raise ValueError('Champ PI invalide')
                    if not isinstance(cfg.get('piValue'), str): raise ValueError('Valeur PI invalide')
                    if cfg.get('sprintCount') not in (3,4): raise ValueError('Nombre de sprints: 3 ou 4')
                    save_json(SETTINGS, cfg); return self.respond(200, cfg)
                if path == '/api/board':
                    cfg = load_json(SETTINGS,{})
                    board = normalize(payload, cfg)
                    save_json(DATA, board); return self.respond(200, board)
                if path == '/api/generate':
                    board=load_json(DATA,{'issues':[],'links':[]})
                    capacity=parse_capacity(CAPACITY)
                    html=(ROOT/'web'/'standalone.html').read_text(encoding='utf-8')
                    content=json.dumps({'board':board,'capacity':capacity,'config':load_json(SETTINGS,{})},ensure_ascii=False).replace('</','<\\/')
                    html=html.replace('/*__DATA__*/','const INITIAL='+content+';')
                    OUTPUT.parent.mkdir(parents=True,exist_ok=True);OUTPUT.write_text(html,encoding='utf-8')
                    return self.respond(200,{'file':'output/board_pip.html','issues':len(board.get('issues',[])),'people':len(capacity['people'])})
                if path == '/api/import':
                    cfg = load_json(SETTINGS,{})
                    board = import_jira(cfg)
                    save_json(DATA, board); return self.respond(200, board)
            self.respond(404, {'error':'Route inconnue'})
        except Exception as exc:
            self.respond(400, {'error':str(exc)})

if __name__ == '__main__':
    print('PI Planner Jira Live : http://127.0.0.1:8765')
    ThreadingHTTPServer(('127.0.0.1', 8765), Handler).serve_forever()

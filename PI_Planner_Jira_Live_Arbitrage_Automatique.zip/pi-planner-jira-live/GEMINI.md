# PI Planner — Jira Live
Lire `agent/SKILL.md` avant tout import. Projet Jira par défaut : `DORZDATAPULCO`.
Le champ PI `Version Cible` est provisoire et modifiable dans `config/settings.json` ou dans l'interface.
Lire obligatoirement `input/Capacite_PI2606.xlsx` pour les capacités, les absences et les dates de sprints.
Les tickets, liens et dépendances viennent du MCP Jira, jamais d'un export Excel supposé contenir les liens.
Générer `output/board_pip.html` depuis l'interface après import. Ne pas inventer les données Jira ni publier dans Jira.

## RÈGLE CAP-SCHED-01 — Capacité déjà nette (OBLIGATOIRE)
- Le fichier obligatoire `input/Template_Capacite_PI_Planner.xlsx` possède les onglets `Capacite`, `Sprints`, `Absences`.
- `Capacite` : NOM, ROLE, SPRINT 1, SPRINT 2, etc. **Chaque valeur est déjà NETTE**. Ne jamais soustraire les absences une deuxième fois ni recalculer les points à partir du calendrier.
- `Sprints` : SPRINT, DATE DEBUT, DATE FIN. `Absences` : NOM, DATE DEBUT, DATE FIN, INDISPONIBILITE (%), MOTIF.
- Les absences servent UNIQUEMENT au positionnement temporel des US et au séquencement intra-sprint. Fusionner les chevauchements sans double-compter.
- Les story points ne sont pas des jours : sans durée estimée ou jalon daté, ne pas promettre une date précise de fin. Signaler les incertitudes.
- ODS avant HDR/PUB, exception même sprint uniquement si le jalon « table ODS créée » précède le début HDR/PUB.
- Un BA ne prend jamais de DOC, même s'il a recetté. Attribuer DOC à un contributeur DEV ou RECETTE non-BA ; sinon non planifié.
- Proposer des splits d'US cohérents entre sprints sans créer automatiquement des tickets Jira.

## Arbitrage automatique
Appliquer ARB-01 (voir agent/SKILL.md). L'agent peut proposer plusieurs scénarios, mais aucune modification de ticket Jira sans confirmation explicite. Le board autonome comporte une analyse locale et des boutons de validation/annulation ; les arbitrages IA nouveaux nécessitent Gemini CLI et ne sont pas générés par le HTML hors ligne.
